package pro.proverkacheka.app.data.repo

import com.squareup.moshi.Moshi
import pro.proverkacheka.app.data.api.CheckRequestDto
import pro.proverkacheka.app.data.api.CheckResponseDto
import pro.proverkacheka.app.data.api.ProverkaApi
import pro.proverkacheka.app.data.api.QrRequestDto
import pro.proverkacheka.app.data.api.ReceiptDto
import pro.proverkacheka.app.data.db.ReceiptDao
import pro.proverkacheka.app.data.db.ReceiptEntity
import java.util.UUID

class CheckRepository(
    private val api: ProverkaApi,
    private val dao: ReceiptDao,
    private val moshi: Moshi
) {
    fun observeHistory() = dao.observeAll()

    suspend fun checkManual(request: CheckRequestDto): ReceiptDto {
        val response = api.check(request)
        return persist(response)
    }

    suspend fun checkQr(qr: String): ReceiptDto {
        val response = api.checkQr(QrRequestDto(qr = qr.trim()))
        return persist(response)
    }

    private suspend fun persist(response: CheckResponseDto): ReceiptDto {
        if (!response.ok || response.receipt == null) {
            throw ApiException(response.message ?: "Чек не найден или ошибка проверки")
        }
        val receipt = response.receipt
        val id = receipt.id?.takeIf { it.isNotBlank() }
            ?: listOfNotNull(receipt.inn, receipt.datetime, receipt.total).joinToString("|")
                .ifBlank { UUID.randomUUID().toString() }

        val adapter = moshi.adapter(ReceiptDto::class.java)
        val json = receipt.rawJson ?: adapter.toJson(receipt)

        dao.upsert(
            ReceiptEntity(
                id = id,
                seller = receipt.seller,
                inn = receipt.inn,
                datetime = receipt.datetime,
                total = receipt.total,
                address = receipt.address,
                json = json,
                savedAt = System.currentTimeMillis()
            )
        )
        return receipt.copy(id = id, rawJson = json)
    }

    suspend fun getLocal(id: String): ReceiptEntity? = dao.getById(id)

    suspend fun delete(id: String) = dao.delete(id)
}

class ApiException(message: String) : Exception(message)

object QrParser {
    /**
     * Строка QR фискального чека: t=...&s=...&fn=...&i=...&fp=...&n=1
     */
    fun toManualRequest(qr: String): CheckRequestDto? {
        val map = linkedMapOf<String, String>()
        qr.trim().split('&').forEach { part ->
            val i = part.indexOf('=')
            if (i > 0) {
                map[part.substring(0, i)] = part.substring(i + 1)
            }
        }
        val fn = map["fn"] ?: return null
        val fd = map["i"] ?: return null
        val fp = map["fp"] ?: return null
        val sum = map["s"] ?: return null
        val t = map["t"] ?: return null
        val n = map["n"]?.toIntOrNull() ?: 1

        // t=YYYYMMDDTHHMM или YYYYMMDDTHHMMSS
        val dateRaw = t.substringBefore('T')
        val timeRaw = t.substringAfter('T', "")
        if (dateRaw.length < 8 || timeRaw.length < 4) return null

        val date = "${dateRaw.substring(0, 4)}-${dateRaw.substring(4, 6)}-${dateRaw.substring(6, 8)}"
        val time = "${timeRaw.substring(0, 2)}:${timeRaw.substring(2, 4)}"

        return CheckRequestDto(
            fn = fn,
            fd = fd,
            fp = fp,
            sum = sum,
            date = date,
            time = time,
            operationType = n
        )
    }
}
