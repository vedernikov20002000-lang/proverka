package pro.proverkacheka.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val Green = Color(0xFF0B3D2E)
private val GreenLight = Color(0xFF1B6B52)
private val Mint = Color(0xFFE8F5F0)
private val Accent = Color(0xFFC4A35A)
private val Surface = Color(0xFFF7FAF8)

private val LightColors = lightColorScheme(
    primary = Green,
    onPrimary = Color.White,
    secondary = Accent,
    onSecondary = Color.Black,
    background = Surface,
    onBackground = Color(0xFF122018),
    surface = Color.White,
    onSurface = Color(0xFF122018),
    primaryContainer = Mint,
    onPrimaryContainer = Green
)

private val DarkColors = darkColorScheme(
    primary = GreenLight,
    onPrimary = Color.White,
    secondary = Accent,
    background = Color(0xFF0A1612),
    onBackground = Mint,
    surface = Color(0xFF122018),
    onSurface = Mint
)

@Composable
fun ProverkaTheme(
    darkTheme: Boolean = false,
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = if (darkTheme) DarkColors else LightColors,
        content = content
    )
}
