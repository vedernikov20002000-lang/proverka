# Android-приложение proverkacheka.pro

Native-клиент на **Kotlin + Jetpack Compose** для сайта [proverkacheka.pro](https://proverkacheka.pro/).

Приложение **не** обращается к серверам ФНС и **не** содержит чужих токенов/секретов.  
Все проверки идут только на ваш backend: `https://proverkacheka.pro/wp-json/proverkacheka/v1/...`

## Возможности

- Проверка по реквизитам (ФН, ФД, ФП, сумма, дата, время, вид чека)
- Сканер QR (CameraX + ML Kit)
- Вставка строки QR
- Локальная история (Room)
- Экспорт JSON через share-sheet

## Как открыть

1. Установите [Android Studio](https://developer.android.com/studio)
2. **Open** → папка `android-app`
3. Sync Gradle → Run на эмуляторе/телефоне

`applicationId`: `pro.proverkacheka.app`

## API на сайте

Плагин: `android-app/wp-mobile-api/proverkacheka-mobile-api.php`

1. Скопируйте в `wp-content/plugins/proverkacheka-mobile-api/` и активируйте.
2. **Настройки → ProverkaCheka API** — вставьте токен из ЛК [proverkacheka.com](https://proverkacheka.com/) (профиль → токен доступа к API).
3. Плагин дергает `https://proverkacheka.com/api/v1/check/get` и отдаёт результат приложению.

### Эндпоинты приложения

| Метод | URL | Тело |
|-------|-----|------|
| POST | `/wp-json/proverkacheka/v1/check` | `{ fn, fd, fp, sum, date, time, operation_type }` |
| POST | `/wp-json/proverkacheka/v1/check-qr` | `{ qr }` |

Без токена в настройках WP проверка вернёт ошибку.

## Структура

```
android-app/
  app/src/main/java/pro/proverkacheka/app/
    MainActivity.kt
    data/          # Retrofit, Room, Repository
    ui/screens/    # Home, Manual, Scanner, Result, History
  wp-mobile-api/   # WordPress REST для приложения
```

## Важно

- Не публикуйте приложение под брендом/иконкой официального приложения ФНС
- Источник данных на сервере должен быть вашим договорным/легальным API, а не клиентскими секретами чужих приложений
