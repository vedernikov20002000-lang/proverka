package pro.proverkacheka.app.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import pro.proverkacheka.app.data.api.CheckRequestDto
import pro.proverkacheka.app.data.api.ReceiptDto
import pro.proverkacheka.app.data.db.ReceiptEntity
import pro.proverkacheka.app.data.repo.ApiException
import pro.proverkacheka.app.data.repo.CheckRepository
import pro.proverkacheka.app.data.repo.QrParser
import retrofit2.HttpException
import java.io.IOException

sealed interface CheckUiState {
    data object Idle : CheckUiState
    data object Loading : CheckUiState
    data class Success(val receipt: ReceiptDto) : CheckUiState
    data class Error(val message: String) : CheckUiState
}

class CheckViewModel(private val repository: CheckRepository) : ViewModel() {

    private val _state = MutableStateFlow<CheckUiState>(CheckUiState.Idle)
    val state: StateFlow<CheckUiState> = _state.asStateFlow()

    val history: StateFlow<List<ReceiptEntity>> = repository.observeHistory()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    fun reset() {
        _state.value = CheckUiState.Idle
    }

    fun checkManual(
        fn: String,
        fd: String,
        fp: String,
        sum: String,
        date: String,
        time: String,
        operationType: Int
    ) {
        viewModelScope.launch {
            _state.value = CheckUiState.Loading
            runCatching {
                repository.checkManual(
                    CheckRequestDto(
                        fn = fn.trim(),
                        fd = fd.trim(),
                        fp = fp.trim(),
                        sum = sum.trim().replace(',', '.'),
                        date = date.trim(),
                        time = time.trim(),
                        operationType = operationType
                    )
                )
            }.fold(
                onSuccess = { _state.value = CheckUiState.Success(it) },
                onFailure = { _state.value = CheckUiState.Error(mapError(it)) }
            )
        }
    }

    fun checkQr(raw: String) {
        viewModelScope.launch {
            _state.value = CheckUiState.Loading
            runCatching {
                // Сначала пробуем endpoint по QR; если бэкенд ждет реквизиты — парсим локально.
                try {
                    repository.checkQr(raw)
                } catch (e: Exception) {
                    val parsed = QrParser.toManualRequest(raw)
                        ?: throw e
                    repository.checkManual(parsed)
                }
            }.fold(
                onSuccess = { _state.value = CheckUiState.Success(it) },
                onFailure = { _state.value = CheckUiState.Error(mapError(it)) }
            )
        }
    }

    fun deleteHistory(id: String) {
        viewModelScope.launch { repository.delete(id) }
    }

    private fun mapError(t: Throwable): String = when (t) {
        is ApiException -> t.message ?: "Ошибка проверки"
        is HttpException -> when (t.code()) {
            404 -> "API на сайте ещё не развёрнут (404). См. README — эндпоинты wp-json/proverkacheka/v1/"
            401, 403 -> "Нет доступа к API сайта. Проверьте авторизацию приложения."
            else -> "Ошибка сервера HTTP ${t.code()}"
        }
        is IOException -> "Нет сети или сайт недоступен"
        else -> t.message ?: "Неизвестная ошибка"
    }

    companion object {
        fun factory(repository: CheckRepository) = object : ViewModelProvider.Factory {
            @Suppress("UNCHECKED_CAST")
            override fun <T : ViewModel> create(modelClass: Class<T>): T {
                return CheckViewModel(repository) as T
            }
        }
    }
}
