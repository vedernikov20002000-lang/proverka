package pro.proverkacheka.app.data.db

import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.RoomDatabase
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "receipts")
data class ReceiptEntity(
    @PrimaryKey val id: String,
    val seller: String?,
    val inn: String?,
    val datetime: String?,
    val total: String?,
    val address: String?,
    val json: String,
    val savedAt: Long
)

@Dao
interface ReceiptDao {
    @Query("SELECT * FROM receipts ORDER BY savedAt DESC")
    fun observeAll(): Flow<List<ReceiptEntity>>

    @Query("SELECT * FROM receipts WHERE id = :id LIMIT 1")
    suspend fun getById(id: String): ReceiptEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(item: ReceiptEntity)

    @Query("DELETE FROM receipts WHERE id = :id")
    suspend fun delete(id: String)
}

@Database(entities = [ReceiptEntity::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun receiptDao(): ReceiptDao
}
