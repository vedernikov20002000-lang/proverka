package pro.proverkacheka.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import pro.proverkacheka.app.ui.CheckViewModel
import pro.proverkacheka.app.ui.screens.HistoryScreen
import pro.proverkacheka.app.ui.screens.HomeScreen
import pro.proverkacheka.app.ui.screens.ManualCheckScreen
import pro.proverkacheka.app.ui.screens.QrStringScreen
import pro.proverkacheka.app.ui.screens.ResultScreen
import pro.proverkacheka.app.ui.screens.ScannerScreen
import pro.proverkacheka.app.ui.theme.ProverkaTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val app = application as ProverkaApp
        setContent {
            ProverkaTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    ProverkaNav(app)
                }
            }
        }
    }
}

@Composable
private fun ProverkaNav(app: ProverkaApp) {
    val nav = rememberNavController()
    val vm: CheckViewModel = viewModel(factory = CheckViewModel.factory(app.container.repository))

    NavHost(navController = nav, startDestination = "home") {
        composable("home") {
            HomeScreen(
                onManual = { nav.navigate("manual") },
                onScanner = { nav.navigate("scanner") },
                onQrString = { nav.navigate("qr_string") },
                onHistory = { nav.navigate("history") }
            )
        }
        composable("manual") {
            ManualCheckScreen(
                viewModel = vm,
                onBack = { nav.popBackStack() },
                onSuccess = { nav.navigate("result") }
            )
        }
        composable("scanner") {
            ScannerScreen(
                viewModel = vm,
                onBack = { nav.popBackStack() },
                onSuccess = { nav.navigate("result") }
            )
        }
        composable("qr_string") {
            QrStringScreen(
                viewModel = vm,
                onBack = { nav.popBackStack() },
                onSuccess = { nav.navigate("result") }
            )
        }
        composable("result") {
            ResultScreen(
                viewModel = vm,
                onBack = {
                    vm.reset()
                    nav.popBackStack("home", inclusive = false)
                },
                onHistory = {
                    vm.reset()
                    nav.navigate("history") {
                        popUpTo("home")
                    }
                }
            )
        }
        composable("history") {
            HistoryScreen(
                viewModel = vm,
                onBack = { nav.popBackStack() },
                onOpen = { id ->
                    nav.navigate("history_item/$id")
                }
            )
        }
        composable(
            route = "history_item/{id}",
            arguments = listOf(navArgument("id") { type = NavType.StringType })
        ) { entry ->
            val id = entry.arguments?.getString("id").orEmpty()
            ResultScreen(
                viewModel = vm,
                historyId = id,
                onBack = { nav.popBackStack() },
                onHistory = { nav.popBackStack() }
            )
        }
    }
}
