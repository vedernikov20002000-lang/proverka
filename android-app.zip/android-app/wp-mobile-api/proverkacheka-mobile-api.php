<?php
/**
 * Plugin Name: ProverkaCheka Mobile API
 * Description: REST API для Android-приложения. Проксирует запросы на https://proverkacheka.com/api/v1/check/get
 * Version: 1.1.0
 * Author: proverkacheka.pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'PROVERKACHEKA_API_URL', 'https://proverkacheka.com/api/v1/check/get' );

/* ------------------------------------------------------------------ */
/* Админка: токен API                                                 */
/* ------------------------------------------------------------------ */

add_action( 'admin_menu', function () {
	add_options_page(
		'ProverkaCheka API',
		'ProverkaCheka API',
		'manage_options',
		'proverkacheka-api',
		'proverkacheka_settings_page'
	);
} );

add_action( 'admin_init', function () {
	register_setting( 'proverkacheka_api', 'proverkacheka_api_token', array(
		'type'              => 'string',
		'sanitize_callback' => 'sanitize_text_field',
		'default'           => '',
	) );
} );

function proverkacheka_settings_page() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	?>
	<div class="wrap">
		<h1>ProverkaCheka API</h1>
		<p>
			Токен берётся в личном кабинете
			<a href="https://proverkacheka.com/" target="_blank" rel="noopener">proverkacheka.com</a>
			→ профиль → «токен доступа к API».
		</p>
		<form method="post" action="options.php">
			<?php settings_fields( 'proverkacheka_api' ); ?>
			<table class="form-table">
				<tr>
					<th><label for="proverkacheka_api_token">API token</label></th>
					<td>
						<input
							type="text"
							id="proverkacheka_api_token"
							name="proverkacheka_api_token"
							value="<?php echo esc_attr( get_option( 'proverkacheka_api_token', '' ) ); ?>"
							class="regular-text"
							autocomplete="off"
						/>
					</td>
				</tr>
			</table>
			<?php submit_button( 'Сохранить' ); ?>
		</form>
		<p><code>POST /wp-json/proverkacheka/v1/check</code> и <code>/check-qr</code></p>
	</div>
	<?php
}

/* ------------------------------------------------------------------ */
/* REST                                                               */
/* ------------------------------------------------------------------ */

add_action( 'rest_api_init', function () {
	register_rest_route( 'proverkacheka/v1', '/check', array(
		'methods'             => 'POST',
		'callback'            => 'proverkacheka_rest_check',
		'permission_callback' => '__return_true',
	) );

	register_rest_route( 'proverkacheka/v1', '/check-qr', array(
		'methods'             => 'POST',
		'callback'            => 'proverkacheka_rest_check_qr',
		'permission_callback' => '__return_true',
	) );
} );

function proverkacheka_get_token() {
	return trim( (string) get_option( 'proverkacheka_api_token', '' ) );
}

/**
 * Дата/время приложения (YYYY-MM-DD + HH:mm) → формат API t=YYYYMMDDTHHMM
 */
function proverkacheka_build_t( $date, $time ) {
	$date = preg_replace( '/\D+/', '', $date );
	$time = preg_replace( '/\D+/', '', $time );
	if ( strlen( $date ) >= 8 && strlen( $time ) >= 4 ) {
		return substr( $date, 0, 8 ) . 'T' . substr( $time, 0, 4 );
	}
	return '';
}

/**
 * Вызов https://proverkacheka.com/api/v1/check/get
 *
 * @param array $fields form-поля API (без token).
 * @return array|WP_Error
 */
function proverkacheka_remote_check( array $fields ) {
	$token = proverkacheka_get_token();
	if ( $token === '' ) {
		return new WP_Error(
			'no_token',
			'Не задан API token. Настройки → ProverkaCheka API.'
		);
	}

	$fields['token'] = $token;

	$response = wp_remote_post( PROVERKACHEKA_API_URL, array(
		'timeout' => 45,
		'body'    => $fields,
		'headers' => array(
			'Cookie' => 'ENGID=1.1',
		),
	) );

	if ( is_wp_error( $response ) ) {
		return $response;
	}

	$code = wp_remote_retrieve_response_code( $response );
	$raw  = wp_remote_retrieve_body( $response );
	$data = json_decode( $raw, true );

	if ( ! is_array( $data ) ) {
		return new WP_Error( 'bad_json', 'Некорректный ответ API', array( 'raw' => $raw, 'http' => $code ) );
	}

	return $data;
}

/**
 * Ответ proverkacheka.com → формат Android-приложения.
 */
function proverkacheka_map_receipt( array $api ) {
	$json = array();
	if ( isset( $api['data']['json'] ) && is_array( $api['data']['json'] ) ) {
		$json = $api['data']['json'];
	} elseif ( isset( $api['data'] ) && is_array( $api['data'] ) ) {
		$json = $api['data'];
	}

	$total_raw = isset( $json['totalSum'] ) ? $json['totalSum'] : ( $json['total'] ?? null );
	$total     = proverkacheka_format_money( $total_raw );

	$items = array();
	$raw_items = $json['items'] ?? $json['ticketItems'] ?? array();
	if ( is_array( $raw_items ) ) {
		foreach ( $raw_items as $item ) {
			if ( ! is_array( $item ) ) {
				continue;
			}
			$items[] = array(
				'name'     => isset( $item['name'] ) ? (string) $item['name'] : null,
				'quantity' => isset( $item['quantity'] ) ? (string) $item['quantity'] : ( isset( $item['qty'] ) ? (string) $item['qty'] : '1' ),
				'price'    => proverkacheka_format_money( $item['price'] ?? null ),
				'sum'      => proverkacheka_format_money( $item['sum'] ?? $item['productSum'] ?? null ),
			);
		}
	}

	$fn = $json['fiscalDriveNumber'] ?? $json['fn'] ?? '';
	$fd = $json['fiscalDocumentNumber'] ?? $json['fd'] ?? $json['i'] ?? '';
	$fp = $json['fiscalSign'] ?? $json['fp'] ?? '';

	return array(
		'id'       => trim( $fn . '-' . $fd . '-' . $fp, '-' ) ?: uniqid( 'check_', true ),
		'seller'   => $json['user'] ?? $json['retailPlace'] ?? $json['seller'] ?? null,
		'inn'      => isset( $json['userInn'] ) ? (string) $json['userInn'] : ( $json['inn'] ?? null ),
		'datetime' => $json['dateTime'] ?? $json['datetime'] ?? null,
		'total'    => $total,
		'address'  => $json['retailPlaceAddress'] ?? $json['address'] ?? null,
		'items'    => $items,
		'rawJson'  => wp_json_encode( $api, JSON_UNESCAPED_UNICODE ),
	);
}

/**
 * Суммы в API часто в копейках (целые). Если похоже на копейки — делим на 100.
 */
function proverkacheka_format_money( $value ) {
	if ( $value === null || $value === '' ) {
		return null;
	}
	if ( is_string( $value ) && strpos( $value, '.' ) !== false ) {
		return $value;
	}
	if ( is_numeric( $value ) ) {
		$num = 0 + $value;
		// целые >= 100 чаще копейки (100 = 1.00)
		if ( is_int( $num ) || ( floor( $num ) == $num && abs( $num ) >= 1 ) ) {
			if ( abs( $num ) >= 100 || ( abs( $num ) > 0 && abs( $num ) < 100 && floor( $num ) == $num ) ) {
				// эвристика: если нет дробной части — копейки
				if ( floor( $num ) == $num ) {
					return number_format( $num / 100, 2, '.', '' );
				}
			}
			return number_format( (float) $num, 2, '.', '' );
		}
		return number_format( (float) $num, 2, '.', '' );
	}
	return (string) $value;
}

function proverkacheka_rest_check( WP_REST_Request $request ) {
	$fn   = sanitize_text_field( (string) $request['fn'] );
	$fd   = sanitize_text_field( (string) $request['fd'] );
	$fp   = sanitize_text_field( (string) $request['fp'] );
	$sum  = sanitize_text_field( (string) $request['sum'] );
	$date = sanitize_text_field( (string) $request['date'] );
	$time = sanitize_text_field( (string) $request['time'] );
	$type = absint( $request['operation_type'] ?: 1 );

	if ( ! $fn || ! $fd || ! $fp || ! $sum || ! $date || ! $time ) {
		return new WP_REST_Response( array(
			'ok'      => false,
			'message' => 'Заполните все реквизиты чека',
		), 400 );
	}

	$t = proverkacheka_build_t( $date, $time );
	if ( ! $t ) {
		return new WP_REST_Response( array(
			'ok'      => false,
			'message' => 'Некорректные дата или время',
		), 400 );
	}

	$result = proverkacheka_remote_check( array(
		'fn' => $fn,
		'fd' => $fd,
		'fp' => $fp,
		't'  => $t,
		'n'  => $type,
		's'  => str_replace( ',', '.', $sum ),
		'qr' => '0',
	) );

	return proverkacheka_to_rest_response( $result );
}

function proverkacheka_rest_check_qr( WP_REST_Request $request ) {
	$qr = sanitize_text_field( (string) $request['qr'] );
	if ( ! $qr ) {
		return new WP_REST_Response( array(
			'ok'      => false,
			'message' => 'Пустая строка QR',
		), 400 );
	}

	// Предпочтительно qrraw — как в документации API
	$result = proverkacheka_remote_check( array(
		'qrraw' => $qr,
	) );

	return proverkacheka_to_rest_response( $result );
}

function proverkacheka_to_rest_response( $result ) {
	if ( is_wp_error( $result ) ) {
		return new WP_REST_Response( array(
			'ok'      => false,
			'message' => $result->get_error_message(),
		), 400 );
	}

	$code = isset( $result['code'] ) ? (int) $result['code'] : 0;

	// Успех по документации: code == 1
	if ( $code === 1 ) {
		return new WP_REST_Response( array(
			'ok'      => true,
			'receipt' => proverkacheka_map_receipt( $result ),
		), 200 );
	}

	// 401 и прочие ошибки API
	$message = 'Чек не получен';
	if ( isset( $result['data'] ) && is_string( $result['data'] ) ) {
		$message = $result['data'];
	} elseif ( isset( $result['message'] ) ) {
		$message = (string) $result['message'];
	}

	$http = ( $code === 401 ) ? 401 : 400;
	return new WP_REST_Response( array(
		'ok'      => false,
		'message' => $message,
		'code'    => $code,
	), $http );
}
