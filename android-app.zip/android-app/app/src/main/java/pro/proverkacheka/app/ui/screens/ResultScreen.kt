package pro.proverkacheka.app.ui.screens

import android.content.Intent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.outlined.Share
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import pro.proverkacheka.app.data.api.ReceiptDto
import pro.proverkacheka.app.data.api.ReceiptItemDto
import pro.proverkacheka.app.ui.CheckUiState
import pro.proverkacheka.app.ui.CheckViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ResultScreen(
    viewModel: CheckViewModel,
    onBack: () -> Unit,
    onHistory: () -> Unit,
    historyId: String? = null
) {
    val context = LocalContext.current
    val state by viewModel.state.collectAsState()
    val history by viewModel.history.collectAsState()
    var local by remember { mutableStateOf<ReceiptDto?>(null) }

    LaunchedEffect(historyId, history) {
        if (historyId != null) {
            val e = history.firstOrNull { it.id == historyId }
            if (e != null) {
                local = ReceiptDto(
                    id = e.id,
                    seller = e.seller,
                    inn = e.inn,
                    datetime = e.datetime,
                    total = e.total,
                    address = e.address,
                    items = emptyList(),
                    rawJson = e.json
                )
            }
        }
    }

    val receipt = local
        ?: (state as? CheckUiState.Success)?.receipt

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Результат") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Назад")
                    }
                },
                actions = {
                    val json = receipt?.rawJson
                    if (!json.isNullOrBlank()) {
                        IconButton(onClick = {
                            val send = Intent(Intent.ACTION_SEND).apply {
                                type = "text/plain"
                                putExtra(Intent.EXTRA_TEXT, json)
                                putExtra(Intent.EXTRA_SUBJECT, "Чек ${receipt?.seller ?: ""}")
                            }
                            context.startActivity(Intent.createChooser(send, "Экспорт JSON"))
                        }) {
                            Icon(Icons.Outlined.Share, contentDescription = "Экспорт")
                        }
                    }
                }
            )
        }
    ) { padding ->
        if (receipt == null) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .padding(20.dp)
            ) {
                Text("Нет данных чека")
                Spacer(Modifier.height(12.dp))
                Button(onClick = onBack) { Text("Назад") }
            }
            return@Scaffold
        }

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 20.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item {
                Spacer(Modifier.height(8.dp))
                Text(
                    receipt.seller ?: "Продавец не указан",
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold
                )
                Text("ИНН: ${receipt.inn ?: "—"}")
                Text("Дата: ${receipt.datetime ?: "—"}")
                Text(
                    "Итого: ${receipt.total ?: "—"} ₽",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.primary
                )
                if (!receipt.address.isNullOrBlank()) {
                    Text(receipt.address.orEmpty())
                }
                Spacer(Modifier.height(8.dp))
                HorizontalDivider()
                Spacer(Modifier.height(8.dp))
                Text("Позиции", fontWeight = FontWeight.SemiBold)
            }

            items(receipt.items) { item: ReceiptItemDto ->
                Card(modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp)) {
                        Text(item.name ?: "Товар", fontWeight = FontWeight.Medium)
                        Text(
                            "${item.quantity ?: "1"} × ${item.price ?: "—"} = ${item.sum ?: "—"}",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
            }

            item {
                Spacer(Modifier.height(12.dp))
                OutlinedButton(onClick = onHistory, modifier = Modifier.fillMaxWidth()) {
                    Text("К истории")
                }
                Spacer(Modifier.height(8.dp))
                Button(onClick = onBack, modifier = Modifier.fillMaxWidth()) {
                    Text("На главную")
                }
                Spacer(Modifier.height(24.dp))
            }
        }
    }
}
