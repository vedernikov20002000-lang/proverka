package pro.proverkacheka.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import pro.proverkacheka.app.ui.CheckUiState
import pro.proverkacheka.app.ui.CheckViewModel

private val operationTypes = listOf(
    1 to "Приход",
    2 to "Возврат прихода",
    3 to "Расход",
    4 to "Возврат расхода"
)

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun ManualCheckScreen(
    viewModel: CheckViewModel,
    onBack: () -> Unit,
    onSuccess: () -> Unit
) {
    var fn by remember { mutableStateOf("") }
    var fd by remember { mutableStateOf("") }
    var fp by remember { mutableStateOf("") }
    var sum by remember { mutableStateOf("") }
    var date by remember { mutableStateOf("") }
    var time by remember { mutableStateOf("") }
    var op by remember { mutableIntStateOf(1) }

    val state by viewModel.state.collectAsState()

    LaunchedEffect(state) {
        if (state is CheckUiState.Success) onSuccess()
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("По реквизитам") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Назад")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 20.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Spacer(Modifier.height(4.dp))
            OutlinedTextField(fn, { fn = it }, label = { Text("ФН") }, modifier = Modifier.fillMaxWidth(), singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
            OutlinedTextField(fd, { fd = it }, label = { Text("ФД") }, modifier = Modifier.fillMaxWidth(), singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
            OutlinedTextField(fp, { fp = it }, label = { Text("ФП") }, modifier = Modifier.fillMaxWidth(), singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
            OutlinedTextField(sum, { sum = it }, label = { Text("Итог") }, modifier = Modifier.fillMaxWidth(), singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), placeholder = { Text("1234.56") })
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(date, { date = it }, label = { Text("Дата") }, modifier = Modifier.weight(1f), singleLine = true, placeholder = { Text("YYYY-MM-DD") })
                OutlinedTextField(time, { time = it }, label = { Text("Время") }, modifier = Modifier.weight(1f), singleLine = true, placeholder = { Text("HH:mm") })
            }

            Text("Вид чека", style = MaterialTheme.typography.labelLarge)
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                operationTypes.forEach { (code, label) ->
                    FilterChip(
                        selected = op == code,
                        onClick = { op = code },
                        label = { Text(label) }
                    )
                }
            }

            if (state is CheckUiState.Error) {
                Text(
                    (state as CheckUiState.Error).message,
                    color = MaterialTheme.colorScheme.error
                )
            }

            Button(
                onClick = {
                    viewModel.checkManual(fn, fd, fp, sum, date, time, op)
                },
                enabled = state !is CheckUiState.Loading &&
                    fn.isNotBlank() && fd.isNotBlank() && fp.isNotBlank() &&
                    sum.isNotBlank() && date.isNotBlank() && time.isNotBlank(),
                modifier = Modifier.fillMaxWidth()
            ) {
                if (state is CheckUiState.Loading) {
                    CircularProgressIndicator(
                        modifier = Modifier.height(20.dp),
                        strokeWidth = 2.dp,
                        color = MaterialTheme.colorScheme.onPrimary
                    )
                } else {
                    Text("Проверить")
                }
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}
