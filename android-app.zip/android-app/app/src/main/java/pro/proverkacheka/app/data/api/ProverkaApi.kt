package pro.proverkacheka.app.data.api

import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass
import retrofit2.http.Body
import retrofit2.http.POST

/**
 * Контракт API вашего сайта https://proverkacheka.pro/
 * Реализуйте эти эндпоинты на WordPress (см. README).
 */
interface ProverkaApi {

    @POST("wp-json/proverkacheka/v1/check")
    suspend fun check(@Body body: CheckRequestDto): CheckResponseDto

    @POST("wp-json/proverkacheka/v1/check-qr")
    suspend fun checkQr(@Body body: QrRequestDto): CheckResponseDto
}

@JsonClass(generateAdapter = true)
data class CheckRequestDto(
    val fn: String,
    val fd: String,
    val fp: String,
    val sum: String,
    val date: String,
    val time: String,
    @Json(name = "operation_type") val operationType: Int = 1
)

@JsonClass(generateAdapter = true)
data class QrRequestDto(
    val qr: String
)

@JsonClass(generateAdapter = true)
data class CheckResponseDto(
    val ok: Boolean = false,
    val message: String? = null,
    val receipt: ReceiptDto? = null
)

@JsonClass(generateAdapter = true)
data class ReceiptDto(
    val id: String? = null,
    val seller: String? = null,
    val inn: String? = null,
    val datetime: String? = null,
    val total: String? = null,
    val address: String? = null,
    val items: List<ReceiptItemDto> = emptyList(),
    val rawJson: String? = null
)

@JsonClass(generateAdapter = true)
data class ReceiptItemDto(
    val name: String? = null,
    val quantity: String? = null,
    val price: String? = null,
    val sum: String? = null
)
