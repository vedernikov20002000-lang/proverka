package pro.proverkacheka.app

import android.app.Application
import pro.proverkacheka.app.data.AppContainer

class ProverkaApp : Application() {
    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this)
    }
}
